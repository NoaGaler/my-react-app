const AlbumsPage = () => {

  return (
    <>

    </>
  );
}
export default AlbumsPage;