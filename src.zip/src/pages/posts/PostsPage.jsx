const PostsPage = () => {

  return (
    <>

    </>
  );
}
export default PostsPage;