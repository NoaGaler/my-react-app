const PhotosPage = () => {

  return (
    <>

    </>
  );
}
export default PhotosPage;